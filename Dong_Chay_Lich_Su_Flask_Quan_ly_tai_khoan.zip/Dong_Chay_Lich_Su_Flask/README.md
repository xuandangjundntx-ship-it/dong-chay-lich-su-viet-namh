# Dòng Chảy Lịch Sử – bản Flask có quản lý tài khoản

Bản này giữ website lịch sử hiện có và bổ sung máy chủ Flask + SQLite để xử lý đăng nhập, đổi mật khẩu và quản trị tài khoản ở phía máy chủ. Không dùng LocalStorage làm cơ chế xác thực.

## Dữ liệu đã nhập

Từ ba bảng danh sách học sinh do người quản lý cung cấp:

| Khối | Số tài khoản |
|---|---:|
| 10 | 503 |
| 11 | 536 |
| 12 | 594 |
| **Tổng** | **1.633** |

Có 9 tên đăng nhập bị trùng trong các bảng nguồn. Để không tạo tài khoản trùng, tài khoản xuất hiện sau được thêm hậu tố lớp (ví dụ `_10c7`). Các trường hợp điều chỉnh được ghi trong `instance/student_accounts_seed.json`.

## Tài khoản khởi tạo

- **Admin:** tên đăng nhập `admin`, mật khẩu tạm `123456`.
- **Học sinh:** tên đăng nhập lấy từ danh sách tài khoản bàn giao; mật khẩu tạm `123456`.
- **Giáo viên:** chưa có danh sách giáo viên trong dữ liệu đầu vào. Admin tạo tài khoản giáo viên và phân công một hoặc nhiều lớp trên bảng quản trị; mật khẩu tạm là `123456`.
- **Cộng đồng:** tự đăng ký bằng email và mật khẩu do người dùng tự chọn; không được truy cập dữ liệu nhà trường.

**Bắt buộc:** Admin, giáo viên và học sinh phải đổi mật khẩu ở lần đăng nhập đầu tiên. Mật khẩu mới tối thiểu 8 ký tự. Admin không thể xem mật khẩu hiện tại; Admin chỉ có thể đặt lại mật khẩu về `123456`, sau đó người dùng phải đổi lại.

## Chạy trên Windows

1. Cài Python 3.10 trở lên.
2. Giải nén thư mục dự án.
3. Nhấp đúp `run_windows.bat`, hoặc chạy thủ công:

```powershell
py -m venv .venv
.venv\Scripts\activate
python -m pip install -r requirements.txt
python app.py
```

4. Mở `http://127.0.0.1:5000`.
5. Đăng nhập Admin bằng `admin` / `123456` và đổi mật khẩu ngay.

Máy chủ tự tạo `instance/dongchay.sqlite3`, băm mật khẩu trước khi lưu, và nhập danh sách học sinh từ `instance/student_accounts_seed.json` khi khởi chạy lần đầu. Không xóa thư mục `instance` sau khi đã sử dụng vì trong đó có cơ sở dữ liệu và khóa phiên đăng nhập.

## Chức năng

- Đăng nhập theo vai trò Admin, giáo viên, học sinh và cộng đồng.
- Đổi mật khẩu; bắt buộc đổi mật khẩu khởi tạo.
- Admin xem bản tổng tài khoản, lọc theo vai trò/khối và tìm theo tên, tên đăng nhập, lớp hoặc email.
- Admin tạo tài khoản giáo viên và phân công nhiều lớp.
- Admin đặt lại mật khẩu tài khoản về `123456`, khóa/mở tài khoản.
- Admin xuất CSV danh sách tài khoản (không chứa mật khẩu).
- Cộng đồng tự đăng ký độc lập, không truy cập dữ liệu học sinh.

## Cảnh báo dữ liệu cá nhân và triển khai

- Danh sách có họ tên và thông tin lớp của học sinh. Đây là dữ liệu cá nhân của học sinh; chỉ người được nhà trường giao nhiệm vụ mới được xử lý.
- **Không tải `instance/`, cơ sở dữ liệu SQLite, file Excel bàn giao tài khoản hoặc tệp seed lên GitHub công khai.** `.gitignore` đã bỏ qua `instance/`, nhưng vẫn phải kiểm tra trước khi commit.
- GitHub Pages chỉ phục vụ website tĩnh, không chạy Flask và không cung cấp xác thực máy chủ. Muốn dùng tài khoản thật trên Internet, phải triển khai ứng dụng Flask trên máy chủ hỗ trợ Python, bật HTTPS, dùng ổ đĩa lưu trữ bền vững và chuyển dữ liệu riêng lên máy chủ qua kênh bảo mật.
- Mật khẩu khởi tạo dùng chung `123456` chỉ dành cho lần cấp đầu. Không phát tán bảng mật khẩu công khai. Sau khi bàn giao, yêu cầu mỗi người đổi mật khẩu riêng.
- Bản này chưa được cấu hình để triển khai trực tiếp lên GitHub Pages. Hãy chạy thử trong mạng/máy kiểm soát trước khi triển khai cho học sinh.

## Cấu trúc

```text
Dong_Chay_Lich_Su_Flask/
├── app.py
├── requirements.txt
├── run_windows.bat
├── README.md
├── .gitignore
├── build_frontend.py
├── static/
│   └── index.html
└── instance/                 # dữ liệu riêng, không đưa lên GitHub công khai
    └── student_accounts_seed.json
```

## Triển khai trực tuyến (không dùng GitHub Pages)

Ứng dụng cần máy chủ Python chạy Flask. Khi triển khai trên dịch vụ hosting:

1. Đưa mã nguồn công khai lên repository nhưng loại trừ toàn bộ thư mục `instance/`.
2. Trên máy chủ, tạo thư mục `instance/` riêng và tải `student_accounts_seed.json` lên bằng kênh riêng tư; không commit tệp này.
3. Thiết lập biến môi trường `DONGCHAY_SECRET_KEY` bằng chuỗi ngẫu nhiên dài, `DONGCHAY_COOKIE_SECURE=1`, và cấu hình ổ đĩa bền vững cho `instance/dongchay.sqlite3`.
4. Dùng lệnh khởi động `gunicorn app:app --bind 0.0.0.0:$PORT` và bật HTTPS.
5. Đăng nhập Admin ngay sau khi triển khai và đổi mật khẩu khởi tạo trước khi gửi đường dẫn cho người dùng.

Nếu nhà trường chưa có máy chủ và người phụ trách kỹ thuật, nên thử nghiệm cục bộ trước; không đưa danh sách học sinh lên website GitHub Pages công khai.

## Số lượng sau lần nhập đầu tiên

Nếu seed file được đặt đúng tại `instance/student_accounts_seed.json` trước khi chạy lần đầu, cơ sở dữ liệu sẽ có **1.634 tài khoản khởi tạo**: 1 Admin và 1.633 học sinh thuộc 35 lớp. Tài khoản giáo viên và tài khoản cộng đồng sẽ tăng thêm khi được tạo/đăng ký.

Nếu dùng gói mã nguồn không kèm dữ liệu học sinh, hãy tạo thư mục `instance/` và chuyển tệp seed riêng tư vào đúng đường dẫn trên trước lần khởi động đầu tiên.
