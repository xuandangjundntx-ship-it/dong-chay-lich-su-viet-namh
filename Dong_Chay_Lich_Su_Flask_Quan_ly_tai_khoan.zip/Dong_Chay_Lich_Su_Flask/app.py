from __future__ import annotations

import csv
import io
import json
import os
import secrets
import sqlite3
import threading
import time
from datetime import timedelta, datetime
from contextlib import contextmanager
from pathlib import Path
from typing import Any

from flask import Flask, jsonify, request, session, send_from_directory, make_response
from werkzeug.security import generate_password_hash, check_password_hash

BASE_DIR = Path(__file__).resolve().parent
INSTANCE_DIR = BASE_DIR / "instance"
INSTANCE_DIR.mkdir(parents=True, exist_ok=True)
DB_PATH = Path(os.environ.get("DONGCHAY_DATABASE", str(INSTANCE_DIR / "dongchay.sqlite3")))
SEED_PATH = INSTANCE_DIR / "student_accounts_seed.json"


def _secret_key() -> str:
    env_key = os.environ.get("DONGCHAY_SECRET_KEY")
    if env_key:
        return env_key
    key_file = INSTANCE_DIR / "session_secret.txt"
    if key_file.exists():
        return key_file.read_text(encoding="utf-8").strip()
    value = secrets.token_urlsafe(48)
    key_file.write_text(value, encoding="utf-8")
    try:
        key_file.chmod(0o600)
    except OSError:
        pass
    return value


app = Flask(__name__, static_folder="static")
app.config.update(
    SECRET_KEY=_secret_key(),
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.environ.get("DONGCHAY_COOKIE_SECURE", "0") == "1",
    PERMANENT_SESSION_LIFETIME=timedelta(hours=8),
    MAX_CONTENT_LENGTH=1 * 1024 * 1024,
)

DB_LOCK = threading.RLock()
LOGIN_FAILURES: dict[str, list[float]] = {}
INITIAL_PASSWORD = "123456"


@contextmanager
def get_db():
    conn = sqlite3.connect(DB_PATH, timeout=20)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def now_text() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def init_db() -> None:
    with DB_LOCK, get_db() as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL COLLATE NOCASE UNIQUE,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL CHECK(role IN ('admin','teacher','student','community')),
            full_name TEXT NOT NULL,
            email TEXT,
            grade INTEGER,
            class_name TEXT,
            must_change_password INTEGER NOT NULL DEFAULT 1,
            is_active INTEGER NOT NULL DEFAULT 1,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS classes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            grade INTEGER NOT NULL,
            class_name TEXT NOT NULL COLLATE NOCASE,
            UNIQUE(grade, class_name)
        );
        CREATE TABLE IF NOT EXISTS teacher_classes (
            teacher_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            class_id INTEGER NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
            PRIMARY KEY(teacher_id, class_id)
        );
        CREATE TABLE IF NOT EXISTS audit_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            actor_id INTEGER,
            action TEXT NOT NULL,
            target_user_id INTEGER,
            detail TEXT,
            created_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_users_role_grade ON users(role, grade);
        CREATE INDEX IF NOT EXISTS idx_users_class ON users(class_name);
        CREATE UNIQUE INDEX IF NOT EXISTS idx_community_email_unique ON users(email) WHERE role='community' AND email IS NOT NULL AND email <> '';
        CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_logs(created_at);
        """)
        admin = conn.execute("SELECT id FROM users WHERE username = 'admin'").fetchone()
        if not admin:
            stamp = now_text()
            conn.execute(
                "INSERT INTO users(username,password_hash,role,full_name,must_change_password,is_active,created_at,updated_at) VALUES(?,?,?,?,1,1,?,?)",
                ("admin", generate_password_hash(INITIAL_PASSWORD), "admin", "Quản trị viên hệ thống", stamp, stamp),
            )
            admin_id = conn.execute("SELECT id FROM users WHERE username='admin'").fetchone()[0]
            conn.execute("INSERT INTO audit_logs(actor_id,action,detail,created_at) VALUES(?,?,?,?)",
                         (admin_id, "bootstrap_admin", "Tạo tài khoản quản trị khởi tạo; yêu cầu đổi mật khẩu", stamp))

        student_count = conn.execute("SELECT COUNT(*) FROM users WHERE role='student'").fetchone()[0]
        if student_count == 0 and SEED_PATH.exists():
            seed = json.loads(SEED_PATH.read_text(encoding="utf-8"))
            stamp = now_text()
            for student in seed.get("students", []):
                grade = int(student["grade"])
                class_name = str(student["class_name"]).strip()
                conn.execute("INSERT OR IGNORE INTO classes(grade,class_name) VALUES(?,?)", (grade, class_name))
                conn.execute(
                    "INSERT OR IGNORE INTO users(username,password_hash,role,full_name,grade,class_name,must_change_password,is_active,created_at,updated_at) VALUES(?,?,?,?,?,?,1,1,?,?)",
                    (student["username"], generate_password_hash(INITIAL_PASSWORD), "student", student["full_name"], grade, class_name, stamp, stamp),
                )
            conn.execute("INSERT INTO audit_logs(actor_id,action,detail,created_at) VALUES(?,?,?,?)",
                         (1, "seed_students", f"Nhập {len(seed.get('students', []))} hồ sơ học sinh từ danh sách được cung cấp", stamp))
        conn.commit()


def audit(conn: sqlite3.Connection, actor_id: int | None, action: str, target_id: int | None = None, detail: str = "") -> None:
    conn.execute("INSERT INTO audit_logs(actor_id,action,target_user_id,detail,created_at) VALUES(?,?,?,?,?)",
                 (actor_id, action, target_id, detail[:500], now_text()))


def user_from_session() -> sqlite3.Row | None:
    user_id = session.get("user_id")
    if not user_id:
        return None
    with get_db() as conn:
        user = conn.execute("SELECT * FROM users WHERE id=? AND is_active=1", (user_id,)).fetchone()
        return user


def public_user(user: sqlite3.Row, conn: sqlite3.Connection | None = None) -> dict[str, Any]:
    result = {
        "id": user["id"], "username": user["username"], "role": user["role"],
        "full_name": user["full_name"], "email": user["email"], "grade": user["grade"],
        "class_name": user["class_name"], "must_change_password": bool(user["must_change_password"]),
        "is_active": bool(user["is_active"]), "created_at": user["created_at"],
    }
    if user["role"] == "teacher" and conn is not None:
        rows = conn.execute("""
            SELECT c.class_name, c.grade FROM classes c
            JOIN teacher_classes tc ON tc.class_id=c.id WHERE tc.teacher_id=?
            ORDER BY c.grade,c.class_name
        """, (user["id"],)).fetchall()
        result["assigned_classes"] = [dict(x) for x in rows]
    return result


def json_error(message: str, status: int = 400):
    return jsonify({"ok": False, "error": message}), status


def csrf_ok() -> bool:
    token = session.get("csrf_token")
    supplied = request.headers.get("X-CSRF-Token", "")
    return bool(token and supplied and secrets.compare_digest(token, supplied))


def require_csrf():
    if not csrf_ok():
        return json_error("Phiên làm việc đã hết hạn hoặc yêu cầu không hợp lệ. Hãy tải lại trang.", 403)
    return None


def require_user(allow_password_change: bool = False, admin: bool = False):
    user = user_from_session()
    if not user:
        return None, json_error("Bạn cần đăng nhập để tiếp tục.", 401)
    if user["must_change_password"] and not allow_password_change:
        return None, json_error("Bạn phải đổi mật khẩu khởi tạo trước khi sử dụng chức năng này.", 403)
    if admin and user["role"] != "admin":
        return None, json_error("Chỉ Admin được thực hiện thao tác này.", 403)
    return user, None


def valid_password(password: str) -> bool:
    return isinstance(password, str) and len(password) >= 8 and len(password) <= 128


@app.after_request
def security_headers(response):
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
    response.headers.setdefault("X-Frame-Options", "SAMEORIGIN")
    response.headers.setdefault("Cache-Control", "no-store")
    return response


@app.get("/")
def home():
    return send_from_directory(app.static_folder, "index.html")


@app.get("/api/csrf")
def api_csrf():
    if not session.get("csrf_token"):
        session["csrf_token"] = secrets.token_urlsafe(32)
    return jsonify({"ok": True, "csrfToken": session["csrf_token"]})


@app.post("/api/login")
def api_login():
    bad = require_csrf()
    if bad:
        return bad
    payload = request.get_json(silent=True) or {}
    username = str(payload.get("username", "")).strip()
    password = str(payload.get("password", ""))
    if not username or not password:
        return json_error("Vui lòng nhập tên đăng nhập và mật khẩu.")
    key = f"{request.remote_addr or 'unknown'}:{username.casefold()}"
    now = time.time()
    recent = [t for t in LOGIN_FAILURES.get(key, []) if now - t < 900]
    if len(recent) >= 10:
        return json_error("Bạn đã thử đăng nhập quá nhiều lần. Hãy thử lại sau 15 phút.", 429)
    with get_db() as conn:
        user = conn.execute("SELECT * FROM users WHERE username=? COLLATE NOCASE", (username,)).fetchone()
        if not user or not user["is_active"] or not check_password_hash(user["password_hash"], password):
            recent.append(now)
            LOGIN_FAILURES[key] = recent
            return json_error("Tên đăng nhập hoặc mật khẩu không đúng, hoặc tài khoản đã bị khóa.", 401)
        LOGIN_FAILURES.pop(key, None)
        session.clear()
        session.permanent = True
        session["user_id"] = user["id"]
        session["csrf_token"] = secrets.token_urlsafe(32)
        audit(conn, user["id"], "login", user["id"], "Đăng nhập thành công")
        conn.commit()
        return jsonify({"ok": True, "user": public_user(user, conn), "csrfToken": session["csrf_token"]})


@app.get("/api/me")
def api_me():
    user = user_from_session()
    if not user:
        return json_error("Chưa đăng nhập.", 401)
    with get_db() as conn:
        fresh = conn.execute("SELECT * FROM users WHERE id=?", (user["id"],)).fetchone()
        return jsonify({"ok": True, "user": public_user(fresh, conn)})


@app.post("/api/logout")
def api_logout():
    bad = require_csrf()
    if bad:
        return bad
    user_id = session.get("user_id")
    if user_id:
        with get_db() as conn:
            audit(conn, user_id, "logout", user_id, "Đăng xuất")
            conn.commit()
    session.clear()
    return jsonify({"ok": True})


@app.post("/api/change-password")
def api_change_password():
    bad = require_csrf()
    if bad:
        return bad
    user, error = require_user(allow_password_change=True)
    if error:
        return error
    payload = request.get_json(silent=True) or {}
    current = str(payload.get("current_password", ""))
    new = str(payload.get("new_password", ""))
    confirm = str(payload.get("confirm_password", ""))
    if not check_password_hash(user["password_hash"], current):
        return json_error("Mật khẩu hiện tại không chính xác.", 400)
    if not valid_password(new):
        return json_error("Mật khẩu mới phải có ít nhất 8 ký tự và không quá 128 ký tự.", 400)
    if new != confirm:
        return json_error("Mật khẩu xác nhận không khớp.", 400)
    if check_password_hash(user["password_hash"], new):
        return json_error("Mật khẩu mới phải khác mật khẩu hiện tại.", 400)
    with get_db() as conn:
        conn.execute("UPDATE users SET password_hash=?,must_change_password=0,updated_at=? WHERE id=?",
                     (generate_password_hash(new), now_text(), user["id"]))
        audit(conn, user["id"], "change_password", user["id"], "Người dùng tự đổi mật khẩu")
        conn.commit()
        updated = conn.execute("SELECT * FROM users WHERE id=?", (user["id"],)).fetchone()
        session["csrf_token"] = secrets.token_urlsafe(32)
        return jsonify({"ok": True, "message": "Đổi mật khẩu thành công.", "user": public_user(updated, conn), "csrfToken": session["csrf_token"]})


@app.post("/api/register-community")
def api_register_community():
    bad = require_csrf()
    if bad:
        return bad
    payload = request.get_json(silent=True) or {}
    name = str(payload.get("full_name", "")).strip()
    username = str(payload.get("username", "")).strip()
    email = str(payload.get("email", "")).strip().lower()
    password = str(payload.get("password", ""))
    if len(name) < 2 or len(name) > 100:
        return json_error("Tên hiển thị cần từ 2 đến 100 ký tự.")
    if not (3 <= len(username) <= 40) or not all(c.isalnum() or c in "._-" for c in username):
        return json_error("Tên đăng nhập chỉ gồm chữ, số, dấu chấm, gạch dưới hoặc gạch ngang (3–40 ký tự).")
    if "@" not in email or len(email) > 120:
        return json_error("Địa chỉ email chưa hợp lệ.")
    if not valid_password(password):
        return json_error("Mật khẩu phải có ít nhất 8 ký tự.")
    stamp = now_text()
    try:
        with get_db() as conn:
            cur = conn.execute(
                "INSERT INTO users(username,password_hash,role,full_name,email,must_change_password,is_active,created_at,updated_at) VALUES(?,?, 'community',?,?,0,1,?,?)",
                (username, generate_password_hash(password), name, email, stamp, stamp),
            )
            user = conn.execute("SELECT * FROM users WHERE id=?", (cur.lastrowid,)).fetchone()
            audit(conn, cur.lastrowid, "community_register", cur.lastrowid, "Đăng ký tài khoản cộng đồng")
            conn.commit()
            session.clear()
            session.permanent = True
            session["user_id"] = user["id"]
            session["csrf_token"] = secrets.token_urlsafe(32)
            return jsonify({"ok": True, "user": public_user(user, conn), "csrfToken": session["csrf_token"]}), 201
    except sqlite3.IntegrityError:
        return json_error("Tên đăng nhập hoặc email đã được sử dụng.", 409)


@app.get("/api/account/classes")
def api_account_classes():
    user, error = require_user()
    if error:
        return error
    if user["role"] != "admin":
        return json_error("Chỉ Admin được truy cập danh sách lớp để phân công.", 403)
    with get_db() as conn:
        rows = conn.execute("SELECT id,grade,class_name FROM classes ORDER BY grade,class_name").fetchall()
        return jsonify({"ok": True, "classes": [dict(x) for x in rows]})


@app.get("/api/teacher/students")
def api_teacher_students():
    user, error = require_user()
    if error:
        return error
    if user["role"] != "teacher":
        return json_error("Chức năng này dành cho tài khoản giáo viên.", 403)
    with get_db() as conn:
        assigned = {r[0] for r in conn.execute("SELECT c.class_name FROM classes c JOIN teacher_classes tc ON tc.class_id=c.id WHERE tc.teacher_id=?", (user["id"],))}
        rows = conn.execute("SELECT id,full_name,username,grade,class_name,is_active FROM users WHERE role='student' ORDER BY grade,class_name,full_name COLLATE NOCASE").fetchall()
        students = []
        for row in rows:
            item = dict(row)
            item["can_edit"] = item["class_name"] in assigned
            students.append(item)
        return jsonify({"ok": True, "students": students, "assigned_classes": sorted(assigned)})


@app.put("/api/teacher/students/<int:student_id>")
def api_teacher_edit_student(student_id: int):
    bad = require_csrf()
    if bad:
        return bad
    user, error = require_user()
    if error:
        return error
    if user["role"] != "teacher":
        return json_error("Chỉ giáo viên được thực hiện thao tác này.", 403)
    payload = request.get_json(silent=True) or {}
    full_name = str(payload.get("full_name", "")).strip()
    if len(full_name) < 2 or len(full_name) > 100:
        return json_error("Họ tên phải từ 2 đến 100 ký tự.")
    with get_db() as conn:
        target = conn.execute("SELECT id,class_name FROM users WHERE id=? AND role='student'", (student_id,)).fetchone()
        if not target:
            return json_error("Không tìm thấy học sinh.", 404)
        assigned = conn.execute("SELECT 1 FROM teacher_classes tc JOIN classes c ON c.id=tc.class_id WHERE tc.teacher_id=? AND c.class_name=?", (user["id"], target["class_name"])).fetchone()
        if not assigned:
            return json_error("Bạn chỉ được sửa học sinh thuộc lớp được phân công.", 403)
        conn.execute("UPDATE users SET full_name=?,updated_at=? WHERE id=?", (full_name, now_text(), student_id))
        audit(conn, user["id"], "teacher_edit_student", student_id, "Giáo viên cập nhật họ tên trong lớp được phân công")
        conn.commit()
    return jsonify({"ok": True, "message": "Đã cập nhật thông tin học sinh."})


@app.get("/api/admin/summary")
def api_admin_summary():
    user, error = require_user(admin=True)
    if error:
        return error
    with get_db() as conn:
        total = conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]
        by_role = {r["role"]: r["n"] for r in conn.execute("SELECT role,COUNT(*) n FROM users GROUP BY role")}
        pending = conn.execute("SELECT COUNT(*) FROM users WHERE must_change_password=1").fetchone()[0]
        locked = conn.execute("SELECT COUNT(*) FROM users WHERE is_active=0").fetchone()[0]
        by_grade = {str(r["grade"]): r["n"] for r in conn.execute("SELECT grade,COUNT(*) n FROM users WHERE role='student' GROUP BY grade")}
        return jsonify({"ok": True, "summary": {"total": total, "students": by_role.get("student",0), "teachers": by_role.get("teacher",0), "community": by_role.get("community",0), "admins": by_role.get("admin",0), "pending_password_change": pending, "locked": locked, "by_grade": by_grade}})


@app.get("/api/admin/accounts")
def api_admin_accounts():
    user, error = require_user(admin=True)
    if error:
        return error
    q = str(request.args.get("q", "")).strip()[:100]
    role = str(request.args.get("role", "")).strip()
    grade = str(request.args.get("grade", "")).strip()
    where, params = [], []
    if q:
        where.append("(full_name LIKE ? OR username LIKE ? OR class_name LIKE ? OR email LIKE ?)")
        wildcard = f"%{q}%"
        params.extend([wildcard,wildcard,wildcard,wildcard])
    if role in ("admin","teacher","student","community"):
        where.append("role=?"); params.append(role)
    if grade in ("10","11","12"):
        where.append("grade=?"); params.append(int(grade))
    sql = "SELECT id,username,role,full_name,email,grade,class_name,must_change_password,is_active,created_at FROM users"
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += " ORDER BY CASE role WHEN 'admin' THEN 0 WHEN 'teacher' THEN 1 WHEN 'student' THEN 2 ELSE 3 END, grade, class_name, full_name COLLATE NOCASE LIMIT 5000"
    with get_db() as conn:
        rows = conn.execute(sql, params).fetchall()
        return jsonify({"ok": True, "accounts": [dict(x) for x in rows], "count": len(rows)})


@app.post("/api/admin/accounts/<int:target_id>/reset-password")
def api_admin_reset_password(target_id: int):
    bad = require_csrf()
    if bad:
        return bad
    user, error = require_user(admin=True)
    if error:
        return error
    with get_db() as conn:
        target = conn.execute("SELECT id,username FROM users WHERE id=?", (target_id,)).fetchone()
        if not target:
            return json_error("Không tìm thấy tài khoản.", 404)
        conn.execute("UPDATE users SET password_hash=?,must_change_password=1,updated_at=? WHERE id=?",
                     (generate_password_hash(INITIAL_PASSWORD), now_text(), target_id))
        audit(conn, user["id"], "admin_reset_password", target_id, "Đặt lại mật khẩu khởi tạo 123456; bắt buộc đổi lại")
        conn.commit()
    return jsonify({"ok": True, "message": f"Đã đặt lại mật khẩu tài khoản {target['username']} về 123456. Người dùng phải đổi mật khẩu khi đăng nhập lại."})


@app.post("/api/admin/accounts/<int:target_id>/toggle-active")
def api_admin_toggle_active(target_id: int):
    bad = require_csrf()
    if bad:
        return bad
    user, error = require_user(admin=True)
    if error:
        return error
    if target_id == user["id"]:
        return json_error("Không thể tự khóa tài khoản Admin đang đăng nhập.", 400)
    with get_db() as conn:
        target = conn.execute("SELECT id,username,is_active FROM users WHERE id=?", (target_id,)).fetchone()
        if not target:
            return json_error("Không tìm thấy tài khoản.", 404)
        new_status = 0 if target["is_active"] else 1
        conn.execute("UPDATE users SET is_active=?,updated_at=? WHERE id=?", (new_status, now_text(), target_id))
        audit(conn, user["id"], "admin_toggle_account", target_id, "Khóa tài khoản" if not new_status else "Mở khóa tài khoản")
        conn.commit()
    return jsonify({"ok": True, "is_active": bool(new_status), "message": "Đã khóa tài khoản." if not new_status else "Đã mở khóa tài khoản."})


@app.post("/api/admin/teachers")
def api_admin_create_teacher():
    bad = require_csrf()
    if bad:
        return bad
    user, error = require_user(admin=True)
    if error:
        return error
    payload = request.get_json(silent=True) or {}
    name = str(payload.get("full_name", "")).strip()
    username = str(payload.get("username", "")).strip()
    email = str(payload.get("email", "")).strip().lower()
    raw_class_ids = payload.get("class_ids", [])
    try:
        class_ids = list(dict.fromkeys(int(x) for x in raw_class_ids)) if isinstance(raw_class_ids, list) else []
    except (TypeError, ValueError):
        class_ids = []
    if len(name) < 2 or len(name) > 100:
        return json_error("Nhập họ tên giáo viên hợp lệ.")
    if not (3 <= len(username) <= 40) or not all(c.isalnum() or c in "._-" for c in username):
        return json_error("Tên đăng nhập chỉ gồm chữ, số, dấu chấm, gạch dưới hoặc gạch ngang (3–40 ký tự).")
    if not isinstance(class_ids, list) or not class_ids:
        return json_error("Chọn ít nhất một lớp được phân công.")
    stamp = now_text()
    try:
        with get_db() as conn:
            valid_ids = {r[0] for r in conn.execute(f"SELECT id FROM classes WHERE id IN ({','.join('?' for _ in class_ids)})", class_ids)}
            if len(valid_ids) != len(set(class_ids)):
                return json_error("Danh sách lớp có mục không hợp lệ.")
            cur = conn.execute(
                "INSERT INTO users(username,password_hash,role,full_name,email,must_change_password,is_active,created_at,updated_at) VALUES(?,?, 'teacher',?,?,1,1,?,?)",
                (username, generate_password_hash(INITIAL_PASSWORD), name, email or None, stamp, stamp),
            )
            teacher_id = cur.lastrowid
            conn.executemany("INSERT INTO teacher_classes(teacher_id,class_id) VALUES(?,?)", [(teacher_id, x) for x in valid_ids])
            audit(conn, user["id"], "admin_create_teacher", teacher_id, "Admin tạo tài khoản giáo viên và phân công lớp")
            conn.commit()
    except sqlite3.IntegrityError:
        return json_error("Tên đăng nhập đã tồn tại.", 409)
    return jsonify({"ok": True, "message": "Đã tạo tài khoản giáo viên.", "username": username, "temporary_password": INITIAL_PASSWORD, "must_change_password": True}), 201


@app.get("/api/admin/export.csv")
def api_admin_export():
    user, error = require_user(admin=True)
    if error:
        return error
    with get_db() as conn:
        rows = conn.execute("SELECT full_name,username,role,email,grade,class_name,must_change_password,is_active,created_at FROM users ORDER BY role,grade,class_name,full_name").fetchall()
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Ho va ten","Ten dang nhap","Vai tro","Email","Khoi","Lop","Can doi mat khau","Trang thai","Ngay tao"])
    for r in rows:
        writer.writerow([r["full_name"],r["username"],r["role"],r["email"] or "",r["grade"] or "",r["class_name"] or "", "Co" if r["must_change_password"] else "Khong", "Dang hoat dong" if r["is_active"] else "Da khoa",r["created_at"]])
    response = make_response("\ufeff" + output.getvalue())
    response.headers["Content-Type"] = "text/csv; charset=utf-8"
    response.headers["Content-Disposition"] = "attachment; filename=danh-sach-tong-tai-khoan.csv"
    return response


@app.get("/api/health")
def api_health():
    with get_db() as conn:
        conn.execute("SELECT 1").fetchone()
    return jsonify({"ok": True, "database": "available"})


# Initialise schema and import student roster on first start.
init_db()

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=int(os.environ.get("PORT", "5000")), debug=False)
